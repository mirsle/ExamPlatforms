/*
 * @Author: 马新杰 
 * @Date: 2019-12-02 11:49:56 
 * @Last Modified by: 马新杰
 * @Last Modified time: 2019-12-03 10:47:52
 */
import React from "react";
import Loadable from "react-loadable"

function Loading() {
  return (
    <div className="loading">
      <img src="timg.gif" alt="none"></img>
    </div>
  )
}

const Home = Loadable({
  loader: () => import("../pages/home/index"),
  loading: Loading
});
const Car = Loadable({
  loader: () => import("../pages/car/index"),
  loading: Loading
});
const Detail = Loadable({
  loader: () => import("../pages/detail/index"),
  loading: Loading
});
export default [
  {
    path: "/home",
    name: "home",
    component: Home,
    children: []
  },
  {
    path: "/car",
    name: "car",
    component: Car,
    children: []
  },
  {
    path: "/detail",
    name: "detail",
    component: Detail,
    children: []

  }

];
